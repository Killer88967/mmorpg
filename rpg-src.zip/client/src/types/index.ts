// ---- shared types ----
export type Item = {
  name: string;
  icon: string;
  color: string;
  rarity: "common" | "uncommon" | "rare" | "epic" | "legendary";
  type: "Material" | "Tool" | "Weapon" | "Block";
  stats?: Record<string, string | number>;
  desc: string;
};

export type RecipeArray = {
  id: string;
  name: string;
  inputs: Record<string, number>;
  station?: string | Record<string, number>;
  output:
    | {
        kind: "item";
        item: string;
        count: number;
      }
    | {
        kind: "tool";
        tool: string;
        count?: number;
      };
}[];

export type RecipeObj = {
  id: string;
  name: string;
  inputs: Record<string, number>;
  output: {
    kind: "item" | "tool";
    item?: string;
    tool?: string;
    count?: number;
  };
};

export type Placeable = {
  item: string;
  name: string;
  icon: string;
  color: number;
};

export type Recipes = Record<string, RecipeObj>;
export type Items = Record<string, Item>;
export type PlaceInfo = Record<string, Placeable>;